import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import Informacion from './components/Informacion';
import Galeria from './components/Galeria';
import Tienda from './components/Tienda';
import Contacto from './components/Contacto';
import './index.css';
import './App.css';

function App() { 
  return ( 
    <Router> 
      <Header /> 
      <Routes> 
        <Route path="/" element={<Home />} /> 
        <Route path="/informacion" element={<Informacion />} /> 
        <Route path="/galeria" element={<Galeria />} /> 
        <Route path="/tienda" element={<Tienda />} /> 
        <Route path="/contacto" element={<Contacto />} /> 
      </Routes> 
      <Footer /> 
    </Router> 
  ); 
}

export default App;

