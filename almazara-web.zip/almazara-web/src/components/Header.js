import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css'; 
import logo from '../assets/logo.png';

function Header() {
  return (
    <header className="header">
      <img src={logo} alt="Logo" className="logo" />
      <nav>
        <ul>
          <li><Link to="/">Inicio</Link></li>
          <li><Link to="/informacion">Información</Link></li>
          <li><Link to="/galeria">Galería</Link></li>
          <li><Link to="/tienda">Tienda</Link></li>
          <li><Link to="/contacto">Contacto</Link></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
