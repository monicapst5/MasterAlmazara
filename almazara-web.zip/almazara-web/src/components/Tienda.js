import React from 'react';
import './Tienda.css';

function Tienda() {
  return (
    <div className="tienda">
      <h1>Venta de nuestro aceite</h1>
      <p>Para realizar una compra o informarte sobre algún producto, por favor, contacta con nosotros a través de nuestros teléfonos o email. Estaremos encantados de atenderte y ayudarte con tu pedido.</p>
      
      <div className="tienda-productos">
        <h2>Formatos de Aceite a la Venta</h2>
        <table className="productos-table">
          <thead>
            <tr>
              <th>Formato</th>
              <th>Precio</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Botellas de 500 ml</td>
              <td>5.00€</td>
            </tr>
            <tr>
              <td>Botellas de 750 ml</td>
              <td>7.00€</td>
            </tr>
            <tr>
              <td>Botellas de 1 L</td>
              <td>9.00€</td>
            </tr>
            <tr>
              <td>Botellas de 2 L</td>
              <td>17.00€</td>
            </tr>
            <tr>
              <td>Botellas de 5 L</td>
              <td>40.00€</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Tienda;
