import React from 'react';
import './Home.css'; 

function Home() {
  return (
    <section id="inicio" className="home-section">
      <div className="overlay">
        <h1>Bienvenidos a Almazara Navarrete</h1>
        <p>Somos una empresa familiar dedicada a la producción y venta de aceite de oliva en Navarrete.</p>
        <p>Contamos con variedades de olivos como: Picual, Arbequina y Hojiblanca.</p>
        <p>No dudes en pasar a conocernos.</p>
      </div>
    </section>
  );
}

export default Home;
