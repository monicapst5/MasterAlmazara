import React from 'react';
import './Informacion.css';

function Informacion() {
  return (
    <div className="informacion">
      <section className="historia">
        <h2>Nuestra Historia</h2>
        <p>
          En 1992, emprendimos una emocionante investigación sobre una innovadora técnica de cultivo para nuestros olivos, con el objetivo de descubrir cómo se comportaría en el particular entorno de nuestra finca. Optamos por experimentar con este método moderno para analizar su adaptación en nuestro terreno único.
        </p>
        <p>
          Después de cuatro años inmersos en este proceso de aprendizaje, descubrimos que el método se ajustaba de manera extraordinaria a nuestras condiciones. A pesar de que el rendimiento por hectárea fue menor en comparación con otras regiones, el aceite obtenido de nuestras aceitunas mostró un perfil de sabor excepcional, con notas aromáticas más intensas y un contenido nutricional enriquecido, ideal para la salud.
        </p>
        <p>
          Impulsados por estos resultados prometedores, decidimos profundizar nuestra inversión en esta técnica de cultivo. En 2010, con una base sólida de conocimientos adquiridos, fundamos la empresa Oliva del Valle. Nos dedicamos a la producción de aceite de oliva virgen extra, comprometidos en mantener la calidad superior desde el cultivo hasta el envasado.
        </p>
        <p>
          Nuestro enfoque meticuloso en cada etapa del proceso asegura que nuestros aceites preserven una riqueza aromática única y una concentración óptima de beneficios para la salud. Esta dedicación nos ha llevado a recibir reconocimiento en diversas competiciones nacionales e internacionales, reflejando el arduo trabajo y la pasión invertidos en cada botella.
        </p>
        <p>
          El éxito y el prestigio obtenido a lo largo de los años son testimonio de nuestro compromiso con la excelencia y nuestra pasión por ofrecer un producto de calidad inigualable.
        </p>
        <p className="aviso">
          ¡Estén atentos! Próximamente habilitaremos las reservas para catas, visitas en días de molienda y jornadas de puertas abiertas. No se pierdan la oportunidad de vivir una experiencia única con nuestros aceites.
        </p>
      </section>
    </div>
  );
}

export default Informacion;
