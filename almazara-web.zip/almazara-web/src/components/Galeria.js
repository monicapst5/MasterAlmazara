import React from 'react';
import './Galeria.css'; 
import photo1 from '../assets/foto1.jpg';
import photo2 from '../assets/foto2.jpg';
import photo3 from '../assets/foto3.jpg';

function Galeria() {
  return (
    <div className="galeria">
      <p>Aquí puedes ver algunas fotos de nuestros olivos y producción.</p>
      <div className="galeria-container">
        <img src={photo1} alt="Foto 1" className="galeria-item" />
        <img src={photo2} alt="Foto 2" className="galeria-item" />
        <img src={photo3} alt="Foto 3" className="galeria-item" />
      </div>
    </div>
  );
}

export default Galeria;
