import React from 'react';
import './Footer.css'; 

function Footer() {
  return (
    <footer className="footer">
      <p>Contacto: +34 616 000 000 | monica.pastor632@comunidadunir.net</p>
      <p>Dirección: Camino Valgaraoz, Navarrete (La Rioja)</p>
    </footer>
  );
}

export default Footer;
